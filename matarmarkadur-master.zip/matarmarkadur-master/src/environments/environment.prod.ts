export const environment = {
  production: true,
  mapbox: {
    accessToken: 'pk.eyJ1IjoiZGFnc3NvbiIsImEiOiJjajk0MTRqdWIzZGxwMzNycGtreDhxMmRxIn0.0zk_7FSvF_LlQ0AD2cChWQ'
  },
  firebase: {
    apiKey: 'AIzaSyAEddonfjKY3IhGNCfJrpYsuhSpLEw-T2w',
    authDomain: 'matur-cc9b3.firebaseapp.com',
    databaseURL: 'https://matur-cc9b3.firebaseio.com',
    storageBucket: 'matur-cc9b3.appspot.com',
    messagingSenderId: '415086235609'
  }
};
